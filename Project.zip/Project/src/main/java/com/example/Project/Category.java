package com.example.Project;

public interface Category {
    String getName();
}

