package com.example.Project;

public class Coupe implements Category {

    public String getName() {
        return "Купе";
    }
}