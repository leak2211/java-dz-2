package com.example.Project;

public class Cabriolet implements Category {

    public String getName() {
        return "Кабриолет";
    }
}